import cv2
import time
import HandTrackingClass as htclass
from math import hypot
import numpy as np
import screen_brightness_control as sbc

wCam, hCam = 1280,720
cap = cv2.VideoCapture(0)
cap.set(3,wCam)
cap.set(4,hCam)
detector = htclass.handDetector(detectonConfidence=0.7)
# screenList = sbc.get_brightness()
screen = sbc.list_monitors()

while True:
    success, img = cap.read()
    img = detector.findHand(img)
    landmarkList = detector.findPostition(img,draw=False)
    if len(landmarkList) != 0:
        print(landmarkList[4])

        #landmark 4 center point
        l4x, l4y = landmarkList[4][1], landmarkList[4][2]
        cv2.circle(img,(l4x,l4y),12,(255,170,0),cv2.FILLED)

        #landmark 8 center point
        l8x,l8y = landmarkList[8][1],landmarkList[8][2]
        cv2.circle(img,(l8x,l8y),12,(255,170,0),cv2.FILLED)

        #center point and line
        cv2.line(img,(l4x,l4y),(l8x,l8y),(255,170,0),2)
        cx, cy = (l4x + l8x)//2, (l4y + l8y)//2
        cv2.circle(img,(cx,cy),8,(255,170,0),cv2.FILLED)
        line_len = int(hypot(l8x-l4x,l8y-l4y))
        cv2.putText(img, f'Line length: {line_len}', (20,50), cv2.FONT_HERSHEY_COMPLEX, 2, (255,170,0), 2)
        brightness = np.interp(line_len,[50,400],[0,100])

        # set brightness level
        if len(screen) != 0:
            cv2.rectangle(img, (20, 150), (40, 350), (255, 170, 0), 3)
            sbc.set_brightness(brightness,screen[0])
            cv2.rectangle(img,(20,150+int(brightness*2)),(40,350),(255,170,0),cv2.FILLED)

    cv2.imshow("Img",img)
    cv2.waitKey(1)