import time
import network
from machine import Pin
from umqtt import MQTTClient
import gc
import random

gc.collect()

ssid = "Laboratorium-IoT"
password = "IoTL@bolatorium"

# Connect to WiFi
wlan = network.WLAN(network.STA_IF)
wlan.active(True)
wlan.connect(ssid, password)
print(f'Connecting to the {ssid} network')
while wlan.isconnected() == False:
    print('Waiting for connection...')
    time.sleep(0.5)
print(f'Connected to the {ssid} network')
print(f'IP adres is {wlan.ifconfig()[0]}')

mqtt_server = "10.23.81.246"
mqtt_username = ""  # username
mqtt_password = ""  # user password
mqtt_publish_topic = "number"  
mqtt_client_id = "rpi_pico_w"

mqtt_client = MQTTClient(
        client_id=mqtt_client_id,
        server=mqtt_server,
#        user=mqtt_username,
#        password=mqtt_password
        )

mqtt_client.connect()

try:
    message_cnt = 0
    while message_cnt < 20:
        val = random.randint(0, 100)
        print(f'Publish {val:.2f}')
        mqtt_client.publish(mqtt_publish_topic, str(val))
        message_cnt += 1
        time.sleep(2)
except Exception as e:
    print(f'Failed to publish message: {e}')
finally:
    mqtt_client.disconnect()
    print("MQTT client disconnected")
    wlan.disconnect()